package com.tampro;

public class NhanVienThuong extends NhanSu{
	private final int PHU_CAP_1 = 300;
	private final int PHU_CAP_2 = 1000;
	private final int LUONG_NHAN_VIEN_THUONG_NGAY = 200;
	
	
	public NhanVienThuong() {
		super();
	}
	@Override
	public void tinhLuong() {
		this.luong  = soNgayLamViec * LUONG_NHAN_VIEN_THUONG_NGAY + PHU_CAP_1;
		int soGioTask = 0;
		for(Task task : dsTask.getListDsTask()) {
			soGioTask += task.getThoiGianThucHien() ;
		}
		if(soGioTask > 35) {
			this.luong += PHU_CAP_2;
		}
		
		
	}
	
	
	

}
