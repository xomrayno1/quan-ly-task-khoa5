package com.tampro;

import java.util.ArrayList;

public class PhongBan implements NhapXuat{
	private String tenPhongBan;
	private String maPhongBan;
	private ArrayList<NhanVienThuong> dsNhanVienThuong;
	private TruongPhongQuanLy truongPhongQuanLy;
	
	
	public PhongBan() {
		Init();
		
	}

	public PhongBan(String tenPhongBan, String maPhongBan) {
		Init();
		this.tenPhongBan = tenPhongBan;
		this.maPhongBan = maPhongBan;
	}
	public String getTenPhongBan() {
		return tenPhongBan;
	}
	public void setTenPhongBan(String tenPhongBan) {
		this.tenPhongBan = tenPhongBan;
	}
	public String getMaPhongBan() {
		return maPhongBan;
	}
	public void setMaPhongBan(String maPhongBan) {
		this.maPhongBan = maPhongBan;
	}
	public ArrayList<NhanVienThuong> getDsNhanVienThuong() {
		return dsNhanVienThuong;
	}
	public void setDsNhanVienThuong(ArrayList<NhanVienThuong> dsNhanVienThuong) {
		this.dsNhanVienThuong = dsNhanVienThuong;
	}
	public TruongPhongQuanLy getTruongPhongQuanLy() {
		return truongPhongQuanLy;
	}
	public void setTruongPhongQuanLy(TruongPhongQuanLy truongPhongQuanLy) {
		this.truongPhongQuanLy = truongPhongQuanLy;
	}
	public void Init() {
		dsNhanVienThuong =  new ArrayList<NhanVienThuong>();
		truongPhongQuanLy = null;
	}
	
	@Override
	public void xuat() {
		System.out.println("=======Thông tin phòng ban========");
		System.out.println("\t[Mã phòng ban] : "+this.maPhongBan
				+"\t[Tên phòng ban] : "+this.tenPhongBan
				);
		if(truongPhongQuanLy == null) {
			System.out.println("Chưa Có Trưởng Phòng");
		}else {
			System.out.println("=======Trưởng Phòng========");
			truongPhongQuanLy.xuatNS();
			System.out.println("===========================");
		}
		for(NhanVienThuong nvt : dsNhanVienThuong) {
			nvt.xuatNS();
		}
	
		System.out.println("=======End========");
	}

	public void xuatTenVaMa() {
		System.out.println("\t[Mã phòng ban] : "+this.maPhongBan
				+"\t[Tên phòng ban] : "+this.tenPhongBan
				);
	}
	
	

}
