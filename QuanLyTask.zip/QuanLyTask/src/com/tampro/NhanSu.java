package com.tampro;

/*
 * Mục Đích : Quản lý nghiệp vụ liên quan Nhansu
 * Ngày tạo : 29/6/2020
 * Version : 1.0
 * Người tạo : com.tampro
 * 
 */
abstract class NhanSu implements NhapXuat{
	protected String ma ;
	protected String ten ; 
	protected int namSinh;
	protected String email;
	protected String sdt;
	protected String maPhongBan;
	protected DanhSachTask dsTask;
	protected float luong;
	protected float soNgayLamViec;
	
	
	public NhanSu() {
		dsTask = new DanhSachTask();
		maPhongBan = "-1";
	}
	public NhanSu(String ma, String ten, int namSinh, String email, String sdt, String maPhongBan,
			DanhSachTask listDsTask, float soNgayLamViec) {
		
		this.ma = ma;
		this.ten = ten;
		this.namSinh = namSinh;
		this.email = email;
		this.sdt = sdt;
		this.maPhongBan = maPhongBan;
		this.dsTask = listDsTask;
		this.soNgayLamViec = soNgayLamViec;
	}

	public NhanSu(String ma, String ten, int namSinh, String email, String sdt,
			float soNgayLamViec) {
		
		this.ma = ma;
		this.ten = ten;
		this.namSinh = namSinh;
		this.email = email;
		this.sdt = sdt;
		this.soNgayLamViec = soNgayLamViec;
	}



	public String getMa() {
		return ma;
	}

	public void setMa(String ma) {
		this.ma = ma;
	}

	public String getTen() {
		return ten;
	}

	public void setTen(String ten) {
		this.ten = ten;
	}

	public int getNamSinh() {
		return namSinh;
	}

	public void setNamSinh(int namSinh) {
		this.namSinh = namSinh;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSdt() {
		return sdt;
	}

	public void setSdt(String sdt) {
		this.sdt = sdt;
	}

	public String getMaPhongBan() {
		return maPhongBan;
	}

	public void setMaPhongBan(String maPhongBan) {
		this.maPhongBan = maPhongBan;
	}

	public DanhSachTask getDsTask() {
		return dsTask;
	}
	public void setDsTask(DanhSachTask dsTask) {
		this.dsTask = dsTask;
	}
	public float getSoNgayLamViec() {
		return soNgayLamViec;
	}

	public void setSoNgayLamViec(float soNgayLamViec) {
		this.soNgayLamViec = soNgayLamViec;
	}

	public float getLuong() {
		return luong;
	}
	
	
	public void xuat() {
		String temp = maPhongBan;
		if(maPhongBan.equalsIgnoreCase("-1")) {
			temp = "Chưa Phân Bổ";
		}
		System.out.println("[Mã] : "+this.ma 
				+"\t[Tên] : "+this.ten 
				+"\t[Năm] : "+this.namSinh 
				+"\t[Email] : "+this.email
				+"\t[SDT] : "+this.sdt
				+"\t[Mã Phòng Ban] : "+temp
				+"\t[Lương] : "+this.luong
				+"\t[Số Ngày Làm Việc] : "+this.soNgayLamViec);	
		if(dsTask.getListDsTask().size() > 0 ) {
			dsTask.xuatMaTenVaThoiGian();
		}
		
	}
	public void xuatNS() {
		String temp = maPhongBan;
		if(maPhongBan.equalsIgnoreCase("-1")) {
			temp = "Chưa Phân Bổ";
		}
		System.out.println("[Mã] : "+this.ma 
				+"\t[Tên] : "+this.ten 
				+"\t[Năm] : "+this.namSinh 
				+"\t[Email] : "+this.email
				+"\t[SDT] : "+this.sdt
				+"\t[Mã Phòng Ban] : "+temp
				+"\t[Lương] : "+this.luong
				+"\t[Số Ngày Làm Việc] : "+this.soNgayLamViec);	
	}
	public void xuatMaVaTen() {
		System.out.println("[Mã] : "+this.ma 
				+"\t[Tên] : "+this.ten );
	}

    public abstract void tinhLuong() ;
	
	
	

}
