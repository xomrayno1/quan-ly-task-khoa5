package com.tampro;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CongTy cty = new CongTy();
		doMenu(sc,cty);
		
	}
	public static void inMenu() {
		System.out.println("1.Tạo dữ liệu");
		System.out.println("2.Xuất danh sách nhân sự.");
		System.out.println("3.Xuất danh sách task.");
		System.out.println("4.Xuất danh sách phòng ban.");
		System.out.println("5.Phân bổ phòng ban.");
		System.out.println("6.Chỉ định trưởng phòng.");
		System.out.println("7.Phân bổ task");
		System.out.println("8.Tìm nhân viên nào đang thực hiện nhiều task nhất.");
		System.out.println("9.Tìm nhân viên tuổi trẻ và đang quản lý nhiều task nhất.");
		System.out.println("10.Phòng ban nào có nhân viên trẻ nhất.");
		System.out.println("11.Xóa một nhân viên.");
		System.out.println("12.Sắp xếp DS Nhân Viên theo thứ tự Task nhiều nhất lên trên cùng như mẫu dùng QuickSort");
		System.out.println("13.Sắp xếp DS Nhân Viên theo thứ tự ABC dùng InterchangeSort");
		System.out.println("14.Tính lương cho toàn công ty");
	}
	public static void doMenu(Scanner sc , CongTy cty) {
		boolean flag = true;
		ArrayList<NhanSu> listNhanSu;
		ArrayList<PhongBan> listPhongBan;
		do {
			inMenu();
			int option = Integer.parseInt(sc.nextLine());
			switch (option) {
			case 1:
				cty.taoDuLieu();
				
				break;
			case 2:
				
				cty.xuatDSNhanSu();
				break;
			case 3:
				cty.xuatDSTask();
				break;
			case 4:
				cty.xuatDSPhongBan();
				break;
			case 5:
				cty.PhanBoNhanVienThuong(sc);
				break;
			case 6:
				cty.chiDinhTruongPhong(sc);
				
				break;
			case 7:
				cty.PhanBoTask(sc);
			
				break;
			case 8:
				 listNhanSu = cty.timNhanSuTaskNhieuNhat();
				cty.outHelperNhanSu(listNhanSu);
				break;
			case 9:
				listNhanSu = cty.timNhanSuTaskNhieuNhatVaTreNhat();
				cty.outHelperNhanSu(listNhanSu);
				break;
			case 10:
				listPhongBan = cty.dsPhongBanCoNhanVienTreNhat();
				cty.outHelperPhongBan(listPhongBan);
				break;
			case 11:
				System.out.println("Nhập mã nhân viên cần xóa");
				String ma = sc.nextLine();
				boolean check = cty.xoaNhanVien(ma);
				if(check) {
					System.out.println("Xóa thành công");
				}else {
					System.out.println("Xóa không thành công");
				}
				break;
			case 12:
				cty.sapXepGiamDanQuickSortkTask();
				cty.xuatDSNhanSu();
				break;
			case 13:
				cty.interchangeSortNhanVien();
				cty.xuatDSNhanSu();
			case 14:
				cty.tinhLuongNS();
				 cty.tinhTongLuong();
				System.out.println("Tổng lương là : "+cty.getTinhLuong());
				break;
			default:
				flag = false;
				break;
			}
			
		} while (flag);
		
	}

}
