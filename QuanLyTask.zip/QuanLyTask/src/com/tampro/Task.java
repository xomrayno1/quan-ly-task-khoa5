package com.tampro;

/*
 * Mục Đích : Quản lý nghiệp vụ liên quan task
 * Ngày tạo : 29/6/2020
 * Version : 1.0
 * Người tạo : com.tampro
 * 
 */
public class Task implements NhapXuat{
	private String  ma ; 
	private String ten;
	private float thoiGianThucHien ;
	private String maNhanVien;
	
	
	
	public Task() {
		maNhanVien = "-1";
	}
	public Task(String ma, String ten, float thoiGianThucHien) {
		maNhanVien = "-1";
		this.ma = ma;
		this.ten = ten;
		this.thoiGianThucHien = thoiGianThucHien;
		
	}
	public String getMa() {
		return ma;
	}
	public void setMa(String ma) {
		this.ma = ma;
	}
	public String getTen() {
		return ten;
	}
	public void setTen(String ten) {
		this.ten = ten;
	}
	public float getThoiGianThucHien() {
		return thoiGianThucHien;
	}
	public void setThoiGianThucHien(float thoiGianThucHien) {
		this.thoiGianThucHien = thoiGianThucHien;
	}
	public String getMaNhanVien() {
		return maNhanVien;
	}
	public void setMaNhanVien(String maNhanVien) {
		this.maNhanVien = maNhanVien;
	}

	public void xuat() {
		String temp = this.maNhanVien;
		if(maNhanVien.equalsIgnoreCase("-1")) {
			temp = "Chưa Phân Bổ";
		}
		System.out.println("\t[Mã task] : "+ma
				+"\t[Tên task] : "+this.ten 
				+"\t[Thời gian] : "+this.thoiGianThucHien 
				+"\t[Mã nhân viên] : "+temp );		
	}
	public void xuatMaTenVaThoiGian() {
		System.out.println("\t[Mã task] : "+ma
				+"\t[Tên task] : "+this.ten 
				+"\t[Thời gian] : "+this.thoiGianThucHien);
	}
	
	

}
