package com.tampro;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DanhSachPhongBan  implements NhapXuat{
 
	private ArrayList<PhongBan> dsPhongBan ;
	
	
	
	public DanhSachPhongBan() {
		dsPhongBan =new  ArrayList<PhongBan>();
	}
	public DanhSachPhongBan(ArrayList<PhongBan> dsPhongBan) {
		
		this.dsPhongBan = dsPhongBan;
	}
	public ArrayList<PhongBan> getDsPhongBan() {
		return dsPhongBan;
	}
	public void setDsPhongBan(ArrayList<PhongBan> dsPhongBan) {
		this.dsPhongBan = dsPhongBan;
	}
	public void addPhongBan(PhongBan phongBan) {
		dsPhongBan.add(phongBan);
	}
	
	public void taoDuLieu() { // doc file
		try {
			FileReader fileReader = new FileReader("src/PhongBan.txt");
			BufferedReader bufferedReader  = new BufferedReader(fileReader);
			String line = "";
			while((line = bufferedReader.readLine()) != null) {
				String[] listInfo = line.split(" # ");
				PhongBan phongBan = new PhongBan(listInfo[1],listInfo[0]);
				dsPhongBan.add(phongBan);
			}
			fileReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void xuat() {
				
		for(PhongBan ds : dsPhongBan) {
			ds.xuat();
		}
		
	}
	public void xuatTenVaMa() {
		for(PhongBan ds : dsPhongBan) {
			ds.xuatTenVaMa();
		}
	}
	public boolean kiemTraPhongBan(String ma) {
		for(PhongBan items : dsPhongBan) {
			if(items.getMaPhongBan().equalsIgnoreCase(ma)) {
				if(items.getTruongPhongQuanLy() != null) {
					return true;
				}
			}
		}
		return false;
	}
	public void xoaNhanVienKhoiPhongBan(String maNV,String maPB) {
		
		PhongBan phongBan = timPhongBanByPB(maPB);
		if(phongBan!=null) {
			if(phongBan.getTruongPhongQuanLy().getMa().equalsIgnoreCase(maNV)) {
				phongBan.setTruongPhongQuanLy(null);
			}else {
				for(NhanVienThuong items : phongBan.getDsNhanVienThuong()) {
					if(items.getMa().equalsIgnoreCase(maNV)) {
						phongBan.getDsNhanVienThuong().remove(items);
					}
					
				}
			}
		}
	}
	public ArrayList<PhongBan> dsPhongBanCoNhanVienTreNhat(int namSinh){
		ArrayList<PhongBan> list = new ArrayList<PhongBan>();
		for(int i = 0 ; i < dsPhongBan.size() ; i++) {
			PhongBan phongBan  = dsPhongBan.get(i);
			if(checkPhongBanCoNhanVienTreNhat(phongBan,namSinh)) {
				list.add(phongBan);
			}
		}
		return list;
	}
	public boolean checkPhongBanCoNhanVienTreNhat(PhongBan phongBan,int namSinh) {
		for(NhanVienThuong ns : phongBan.getDsNhanVienThuong()) {
			if(ns.getNamSinh() == namSinh) {
				return true;
			}
		}
		return false;
	}
	public PhongBan timPhongBanByPB(String maPB) {
		for(PhongBan phongBan : dsPhongBan) {
			if(phongBan.getMaPhongBan().equalsIgnoreCase(maPB)) {
				return phongBan;
			}
		}
		return null;
	}
	public PhongBan timPhongBanByMaTP(String maTP) {
		for(PhongBan phongBan : dsPhongBan) {
			if(phongBan.getTruongPhongQuanLy().getMaPhongBan().equalsIgnoreCase(maTP)) {
				return phongBan;
			}
		}
		return null;
	}
}
