package com.tampro;

import java.util.ArrayList;
import java.util.Scanner;

public class CongTy implements NhapXuat{
	private DanhSachNhanSu dsNhanSu;
	private DanhSachTask dsTask;
	private DanhSachPhongBan dsPhongBan;
	private String ten;
	private String maSoThue;
	private float tinhLuong;
	
	public CongTy() {
		ten = "com.tampro";
		maSoThue = "78G";
		dsNhanSu = new DanhSachNhanSu();
		dsPhongBan = new DanhSachPhongBan();
		dsTask = new DanhSachTask();
	}
	public CongTy(String ten, String maSoThue) {
		this.ten = ten;
		this.maSoThue = maSoThue;
	}

	public DanhSachNhanSu getDsNhanSu() {
		return dsNhanSu;
	}
	public void setDsNhanSu(DanhSachNhanSu dsNhanSu) {
		this.dsNhanSu = dsNhanSu;
	}
	public DanhSachPhongBan getDsPhongBan() {
		return dsPhongBan;
	}
	public void setDsPhongBan(DanhSachPhongBan dsPhongBan) {
		this.dsPhongBan = dsPhongBan;
	}
	public void setDsTask(DanhSachTask dsTask) {
		this.dsTask = dsTask;
	}

	public DanhSachTask getDsTask() {
		return dsTask;
	}
	public String getTen() {
		return ten;
	}
	public void setTen(String ten) {
		this.ten = ten;
	}
	public String getMaSoThue() {
		return maSoThue;
	}
	public void setMaSoThue(String maSoThue) {
		this.maSoThue = maSoThue;
	}
	public float getTinhLuong() {
		return tinhLuong;
	}

	public void xuatTTCongTy() {
		System.out.println("\t[Tên] : "+this.ten
				+"\t[Mã số thuê] : "+this.maSoThue
				);
	}
	@Override
	public void xuat() {
		// TODO Auto-generated method stub
		System.out.println("\t[Tên] : "+this.ten
				+"\t[Mã số thuê] : "+this.maSoThue
				);
		dsNhanSu.xuat();
		dsPhongBan.xuat();
		dsTask.xuat();
	}
	public void xuatDSNhanSu() {
		dsNhanSu.xuat();
	}
	public void xuatDSPhongBan() {
		dsPhongBan.xuat();
	}
	public void xuatDSTask() {
		dsTask.xuat();
	}
	public void taoDuLieu() {
		dsNhanSu.taoDuLieu();
		dsTask.taoDuLieu();
		dsPhongBan.taoDuLieu();
	}
	public void tinhLuongNS() {
		
		dsNhanSu.tinhLuong();
	}
	public  void tinhTongLuong() {
		
		float tongLuong = 0 ;
		for(NhanSu ns : dsNhanSu.getDsNhanSu()) {
			tongLuong += ns.luong;
		}
		this.tinhLuong = tongLuong;
	}

	public ArrayList<NhanSu> timNhanSuTaskNhieuNhat(){ // 8
		
		return dsNhanSu.timNhanSuTaskNhieuNhat(dsNhanSu.getDsNhanSu());
	}
	public ArrayList<NhanSu> timNhanSuTaskNhieuNhatVaTreNhat(){ // 9
		
		return dsNhanSu.timNhanSuTaskNhieuNhatVaTreNhat();
	}
	public ArrayList<PhongBan> dsPhongBanCoNhanVienTreNhat(){
		int namSinh = dsNhanSu.tuoiNhanVienTreNhat();
		return dsPhongBan.dsPhongBanCoNhanVienTreNhat(namSinh);
	}
	public void sapXepGiamDanQuickSortkTask() {
		dsNhanSu.sapXepGiamDanQuickSortkTask(dsNhanSu.getDsNhanSu(), 0, dsNhanSu.getDsNhanSu().size()-1);
	}
	public void interchangeSortNhanVien() {
		dsNhanSu.interchangeSortNhanVien();
	}
	public PhongBan timPhongBan(String maPB) {
		for(PhongBan items : dsPhongBan.getDsPhongBan()) {
			if(items.getMaPhongBan().equalsIgnoreCase(maPB)) {
				return items;
			}
		}
		return null;
	}
	public void xuatDsPhongBanTenVaMa() {
		for(PhongBan ds : dsPhongBan.getDsPhongBan()) {
			ds.xuatTenVaMa();
		}
	}
	public boolean kiemTraPhongBan(String ma) {
		return dsPhongBan.kiemTraPhongBan(ma);
	}
	public NhanSu timNhanSu(String ma) {
		return dsNhanSu.timNhanSu(ma);
	}
	public void chonTask(Scanner sc,Task task) {
		xuatDSNhanSu();
		NhanSu ns;
		do {
			System.out.println("Nhập mã nhân sự");
			String ma = sc.nextLine();
			ns = timNhanSu(ma);
			if(ns != null) {
				task.setMaNhanVien(ns.getMa());
				ns.getDsTask().addTask(task);
			}
		}while(ns == null);
		
	}
	public void PhanBoTask(Scanner sc) {
		for(Task task : dsTask.getListDsTask()) {
			if(task.getMaNhanVien().equals("-1")) {
				task.xuat();
				boolean flag = true;
				do {
					System.out.println("Bạn có muốn phân bổ task cho nhân viên không");
					System.out.println("1.Có  2.Không");
					int option = Integer.parseInt(sc.nextLine());
					switch (option) {
					case 1:
						chonTask(sc,task);
					case 2:
						flag = false;
						break;
					default:
						System.out.println("Chọn 1 hoặc 2");
						break;
					}
				}while(flag);
			}
		}
	}
	
	public void chonPhongBan(Scanner sc,NhanSu nhanSu) {
		xuatDsPhongBanTenVaMa();
		PhongBan phongBan = null;
		do {
			System.out.println("Chọn phòng ban");
			String ma = sc.nextLine();
		    phongBan = timPhongBan(ma);
		   
			if(phongBan != null) {
				nhanSu.setMaPhongBan(phongBan.getMaPhongBan());
				phongBan.getDsNhanVienThuong().add((NhanVienThuong) nhanSu);
			}
		}while(phongBan == null);
		
	}
	public void PhanBoNhanVienThuong(Scanner sc) {
		for(NhanSu nhanSu : dsNhanSu.getDsNhanSu()) {
			if(nhanSu instanceof NhanVienThuong) {
				nhanSu.xuat();
				boolean flag = true;
				do {
					System.out.println("Bạn có muốn phân bổ vào phòng ban hay không");
					System.out.println("1.Có 2.Không");
					int option = Integer.parseInt(sc.nextLine());
					switch (option) {
					case 1:
						chonPhongBan(sc,nhanSu);
					case 2:
						flag = false;
						break;
					default:
						System.out.println("Chọn 1 hoặc 2");
						break;
					}
				}while(flag);
			}
		}
	}
	public void chonPhongBanTruonPhong(Scanner sc,NhanSu nhanSu) {
		xuatDsPhongBanTenVaMa();
		PhongBan phongBan = null;
		do {
			System.out.println("Chọn phòng ban");
			String ma = sc.nextLine();
		    phongBan = timPhongBan(ma);
		    NhanSu ns = timTruongPhongByMaPB(ma);
		    if(phongBan != null) {
	    		if(ns != null) {
	    			ns.setMaPhongBan("-1");
	    		}
				nhanSu.setMaPhongBan(phongBan.getMaPhongBan());
				phongBan.setTruongPhongQuanLy((TruongPhongQuanLy) nhanSu);
			}
		}while(phongBan == null);
		
	}
	public  void chiDinhTruongPhong(Scanner sc) {
		for(NhanSu ns : dsNhanSu.getDsNhanSu()) {
			if(ns instanceof TruongPhongQuanLy) {
				ns.xuat();
				boolean flag = true;
				do {
					System.out.println("Bạn có muốn phân bổ vào phòng ban hay không");
					System.out.println("1.Có 2.Không");
					int option = Integer.parseInt(sc.nextLine());
					switch (option) {
					case 1:
						chonPhongBanTruonPhong(sc,ns);
					case 2:
						flag = false;
						break;
					default:
						System.out.println("Chọn 1 hoặc 2");
						break;
					}
				}while(flag);
			}
		}
		
	}
	public NhanSu timTruongPhongByMaPB(String ma) {
		return dsNhanSu.timTruongPhongByMaPB(ma);
	}
	public PhongBan timPhongBanByPB(String maPB) {
		return dsPhongBan.timPhongBanByPB(maPB);
	}
	public void xoaNhanVienKhoiPB(String maNV,String maPB) {
		dsPhongBan.xoaNhanVienKhoiPhongBan(maNV, maPB);
	}
	public boolean xoaNhanVien(String maNV) {
		NhanSu ns = timNhanSu(maNV);
		if(ns != null) {
			xoaNhanVienKhoiPB(maNV,ns.getMaPhongBan());
			return dsNhanSu.xoaNhanVien(maNV);
		}
		return false;
	}
	public void outHelperNhanSu(ArrayList<NhanSu> list) {
		for(NhanSu ns : list) {
			ns.xuat();
		}
	}
	public void outHelperPhongBan(ArrayList<PhongBan> list) {
		for(PhongBan pb : list) {
			pb.xuatTenVaMa();
		}
	}
}
