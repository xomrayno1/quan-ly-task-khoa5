package com.tampro;

public interface NhapXuat {
	void xuat();

}
