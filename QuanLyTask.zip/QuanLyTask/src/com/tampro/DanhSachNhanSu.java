package com.tampro;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class DanhSachNhanSu implements NhapXuat {
	private ArrayList<NhanSu> dsNhanSu ;

	public DanhSachNhanSu(ArrayList<NhanSu> dsNhanSu) {
		this.dsNhanSu = dsNhanSu;
	}

	public DanhSachNhanSu() {
		dsNhanSu =new  ArrayList<NhanSu>();
	}

	public ArrayList<NhanSu> getDsNhanSu() {
		return dsNhanSu;
	}

	public void setDsNhanSu(ArrayList<NhanSu> dsNhanSu) {
		this.dsNhanSu = dsNhanSu;
	}
	public void addNhanSu(NhanSu ns) {
		dsNhanSu.add(ns);
	}
	
	public void taoDuLieu() { // doc file
		try {
			FileReader fileReader = new FileReader("src/DSNV.txt");
			BufferedReader bufferedReader  = new BufferedReader(fileReader);
			String line ;
			while((line = bufferedReader.readLine()) != null) {
				String[] listInfo = line.split(" # ");
				NhanSu ns;
				if(listInfo[listInfo.length - 1].contentEquals("true")){
					ns  = new TruongPhongQuanLy();
				}else {
					ns = new NhanVienThuong();
				}
				ns.setMa(listInfo[0]);
				ns.setTen(listInfo[1]);
				ns.setNamSinh(Integer.parseInt(listInfo[2]));
				ns.setEmail(listInfo[3]);
				ns.setSdt(listInfo[4]);
				ns.setSoNgayLamViec(Float.parseFloat(listInfo[5]));
				dsNhanSu.add(ns);
			}
			fileReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void xuat() {
		for(NhanSu ns : dsNhanSu) {
			ns.xuat();
		}
	}
	public void xuatMaTenVaThoiGian() {
		for(NhanSu ns : dsNhanSu) {
			ns.xuat();
		}
	}
	public void xuatTruongPhong() {
		for(NhanSu ns : dsNhanSu) {
			if(ns instanceof TruongPhongQuanLy) {
				ns.xuat();
			}
		}
	}
    public void xuatNhanVienThuong() {
    	for(NhanSu ns : dsNhanSu) {
			if(ns instanceof NhanVienThuong) {
				ns.xuat();
			}
		}
	}

    public void tinhLuong() {
    	for(NhanSu ns : dsNhanSu) {
    		if(ns instanceof NhanVienThuong) {
    			ns.tinhLuong();
    		}else {
    			int soNguoi = soNguoi(ns.getMaPhongBan());
    			ns.tinhLuong();
    			if(soNguoi > 0) {
    				ns.luong += 200 * soNguoi;
    			}
    			
    		}
    			
			
		}
    }
    public int soNguoi(String maPB) {
    	int soNg =0;
		for(NhanSu ns : dsNhanSu) {
			if(ns.getMaPhongBan().equalsIgnoreCase(maPB)) {
				soNg++;
			}
		}
		return soNg-1;
    }
	public NhanSu timTruongPhongByMaPB(String ma) {
		for(NhanSu ns : dsNhanSu) {
			if(ns instanceof TruongPhongQuanLy) {
				if(ns.getMaPhongBan().equalsIgnoreCase(ma)) {
					return ns;
				}
			}
		}
		return null;
	}
	public NhanSu timNhanSu(String ma) {
		for(NhanSu ns : dsNhanSu) {
			if(ns.getMa().equalsIgnoreCase(ma)) {
				return ns;
			}
		}
		return null;
	}
	public void interchangeSortNhanVien() {
		for(int i = 0 ; i < dsNhanSu.size() ; i++) {
			for(int j = i ; j < dsNhanSu.size() ;j++) {
				if(dsNhanSu.get(i).getTen().compareToIgnoreCase(dsNhanSu.get(j).getTen()) >  0) { 
					Collections.swap(dsNhanSu, i, j);
				}
			}
		}
	}
	public ArrayList<NhanSu> timNhanSuTaskNhieuNhat(ArrayList<NhanSu> listNS){
		ArrayList<NhanSu> dsNhanSuMax =  new ArrayList<NhanSu>();
		int indexMax = 0;
		for(int i = 1 ; i < listNS.size() ; i++) {
			int current = listNS.get(i).getDsTask().getListDsTask().size();
			int max = listNS.get(indexMax).getDsTask().getListDsTask().size();
			if(current > max) {
				indexMax = i;
			}
		}
		for(int i = indexMax ; i < listNS.size() ; i++) {
			int current = listNS.get(i).getDsTask().getListDsTask().size();
			int max = listNS.get(indexMax).getDsTask().getListDsTask().size();
			if(current == max) {
				dsNhanSuMax.add(listNS.get(i));
			}
		}	
		return dsNhanSuMax;
	}
	public  ArrayList<NhanSu> timNhanSuTaskNhieuNhatVaTreNhat(){ // 9
		ArrayList<NhanSu> listNVTreNhat = new ArrayList<NhanSu>();
		int tuoiMin = tuoiNhanVienTreNhat();
		for(NhanSu ns : dsNhanSu) {
			if(ns.getNamSinh() == tuoiMin) {
				listNVTreNhat.add(ns);
			}
		}
		ArrayList<NhanSu> dsNhanSuMax =  timNhanSuTaskNhieuNhat(listNVTreNhat);
		
		
		return dsNhanSuMax;
	}
	public int tuoiNhanVienTreNhat() {
		int max = dsNhanSu.get(0).getNamSinh();
		for(NhanSu ns : dsNhanSu) {
			if(max < ns.getNamSinh()) {
				max = ns.getNamSinh();
			}
		}
		return max ;
	}

	
	public boolean xoaNhanVien(String ma) {
		for(int i =0 ; i < dsNhanSu.size() ; i++) {
			if(dsNhanSu.get(i).getMa().equalsIgnoreCase(ma)) {
				NhanSu ns = dsNhanSu.get(i);
				
				
				for(Task task : ns.getDsTask().getListDsTask()) {
					task.setMaNhanVien("-1");
				}
				dsNhanSu.remove(i);
				return true;
			}
		}
		return false;
	}
	public void sapXepGiamDanQuickSortkTask(ArrayList<NhanSu> list,int left,int right) {
		// 3 4 5 2 7
		int x = list.get((left + right) / 2).getDsTask().getListDsTask().size();
		int i = left;
		int j = right;
		do {
			while(list.get(i).getDsTask().getListDsTask().size() > x) {
				i++;
			}
			while(list.get(j).getDsTask().getListDsTask().size() < x) {
				j--;
			}
			if(i <= j ) {
				Collections.swap(list, i, j);
				i++;
				j--;
			}
		}while(i < j);
		if(left < j ) {
			sapXepGiamDanQuickSortkTask(list,left,j);
		}
		if(i < right ) {
			sapXepGiamDanQuickSortkTask(list,i,right);
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
