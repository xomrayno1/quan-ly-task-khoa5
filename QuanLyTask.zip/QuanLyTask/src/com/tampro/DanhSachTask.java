package com.tampro;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DanhSachTask  implements NhapXuat{

	private ArrayList<Task> listDsTask;
	
	public DanhSachTask() {
		 listDsTask =  new ArrayList<Task>();
	}

	public ArrayList<Task> getListDsTask() {
		return listDsTask;
	}

	public void setListDsTask(ArrayList<Task> listDsTask) {
		this.listDsTask = listDsTask;
	}
	public void addTask(Task task) {
		listDsTask.add(task);
	}
	public void taoDuLieu() { // doc file
		try {
			FileReader fileReader = new FileReader("src/Task.txt");
			BufferedReader bufferedReader  = new BufferedReader(fileReader);
			String line = "";
			while((line = bufferedReader.readLine()) != null) {
				String[] listInfo = line.split(" # ");
				Task task = new Task(listInfo[0],listInfo[1],Float.parseFloat(listInfo[2]));
				listDsTask.add(task);
			}
			fileReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public void xuat() {
		for(Task items : listDsTask) {
			items.xuat();
		}
	}
	public void xuatMaTenVaThoiGian() {
		for(Task items : listDsTask) {
			items.xuatMaTenVaThoiGian();
		}
	}
	

}
