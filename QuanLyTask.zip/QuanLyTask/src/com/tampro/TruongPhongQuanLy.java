package com.tampro;

public class TruongPhongQuanLy extends NhanSu{
	private final int LUONG_NHAN_VIEN_THUONG_NGAY = 200;
	private final int LUONG_NHAN_VIEN_THUONG_TRUONG_PHONG = 300;


	

	public TruongPhongQuanLy() {
		super();
	}
	@Override
	public void tinhLuong() {
		
		this.luong = soNgayLamViec * LUONG_NHAN_VIEN_THUONG_TRUONG_PHONG;
		
	}
	

}
